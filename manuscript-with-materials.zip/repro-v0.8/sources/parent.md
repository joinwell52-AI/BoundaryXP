PM 负责本次系统环境核查，安排 OPS 检查测试机的操作系统、磁盘余量和服务进程。OPS 必须生成 environment-check.md，QA 复核报告后由 PM 提交给 ADMIN。整个任务须在 40 分钟内完成，不得修改系统配置。
