// Read the saved program result. No model calls, source parsing or computation.
const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
const states={PARTIAL:'部分计算：存在缺口',CONFLICT:'发现约束冲突',CALCULATED_FRAGMENT:'受支持的明确约束已计算',UNKNOWN:'未知：未提供运行观测',TRUE:'成立',FALSE:'不成立',satisfiable:'存在可行组合',unsatisfiable:'不存在可行组合',NOT_APPLICABLE:'没有此类明确计算项',CALCULATED:'已计算',UNSUPPORTED:'超出受支持计算范围'};
export function renderBoundaryCalculations(container,trace,onEvidence=()=>{},onObserve=null){
 container.replaceChildren();container.append(el('h2','最终结果：7+1边界数学计算'));
 const c=trace?.boundary_calculations;
 if(!c){container.append(el('p',trace?'此历史记录没有保存本版计算阶段；未重算、未补造。':'等待IR与固定7+1生成后，计算程序直接消费同一IR。'));return;}
 const labels=new Map((trace.ir.entities??[]).map(x=>[x.id,x.label]));labels.set('ROOT','根任务');
 for(const f of trace.ir.facts.filter(x=>x.kind==='EVENT'))labels.set(f.event.id,f.event.predicate+'（'+(f.roles??[]).map(r=>(r.role==='PERFORMER'?'执行者：':'')+(r.entity?.label??r.entity_id)).join('、')+'）');
 const name=id=>labels.get(id)??id;
 const atoms=new Map(c.boolean.atoms.map(x=>[x.id,x.meaning]));
  const atomText=a=>a?.kind==='PROPERTY_TEST'?(a.test.operator==='IMMEDIATE'?'立即执行 '+name(a.test.target_id)+'（不得无故延迟，非0秒期限）':name(a.test.target_id)+(a.test.property_path.length?'.'+a.test.property_path.join('.'):'')+' '+a.test.operator+' '+JSON.stringify(a.test.value)):a?.kind==='OUTPUT_BEHAVIOR'?'产物 '+name(a.artifact_id)+' 的内部行为 '+name(a.event_id):a?.kind==='STATE'?a.predicate+'('+a.args.map(name).join('、')+')':a?.event_id?'执行 '+name(a.event_id):a?.kind==='TASK_COMPLETE'?'任务完成':a?.kind==='TASK_STOP'?'任务停止':null;
 const formula=x=>typeof x==='boolean'?String(x):x.var?(atomText(atoms.get(x.var))??x.var):x.not?'非('+formula(x.not)+')':x.all?'('+x.all.map(formula).join(' 且 ')+')':x.any?'('+x.any.map(formula).join(' 或 ')+')':x.implies?'('+formula(x.implies[0])+' ⇒ '+formula(x.implies[1])+')':'未支持表达式';
 const row=(section,text,sources)=>{const p=el('p',text);if(sources?.length){const button=el('button','查看本条原文依据');button.className='secondary';button.onclick=()=>onEvidence(sources);p.append(document.createTextNode(' '),button);}section.append(p);};
 const section=title=>{const d=el('details');d.open=true;d.append(el('summary',title));container.append(d);return d;};
 const math=c.mathematical_results;
 if(math){
  const final=section('数学计算结果：操作数 → 运算 → 计算值');
  const members=x=>'{'+x.members.map(v=>v.label).join('、')+'}';
  row(final,'输入集合 I = '+members(math.sets.input)+'；基数 '+math.sets.input.cardinality,math.sets.input.sources);
  row(final,'产物集合 O = '+members(math.sets.output)+'；基数 '+math.sets.output.cardinality,math.sets.output.sources);
  row(final,'I∩O = '+(math.sets.intersection.cardinality?members(math.sets.intersection):'∅')+'；I∪O的基数 = '+math.sets.union.cardinality+'；集合计算状态 '+math.sets.intersection.status,math.sets.proof.sources);
  for(const x of math.intervals){const value=(x.lower?.inclusive?'[':'(')+(x.lower?.value??'-∞')+','+(x.upper?.value??'+∞')+(x.upper?.inclusive?']':')');row(final,'区间交集：'+name(x.subject)+' ∈ '+value+' '+x.unit+'；'+(x.empty?'空集：冲突':'非空'),x.proof.sources);}
  for(const x of math.completion){
   if(x.status!=='CALCULATED'){row(final,'完成公式未算：'+x.reason,x.proof.sources);continue;}
   const meanings=new Map(x.atoms.map(a=>[a.id,a.state?a.state.predicate+'('+a.state.args.map(name).join('、')+')':a.test.operator+'('+name(a.test.target_id)+')']));
   const expression=f=>typeof f==='boolean'?String(f):f.var?(meanings.get(f.var)??f.var):f.not?'非('+expression(f.not)+')':f.all?'('+f.all.map(expression).join(' 且 ')+')':f.any?'('+f.any.map(expression).join(' 或 ')+')':'未支持';
   row(final,'完成前提 K = '+expression(x.formula),x.proof.sources);
   row(final,'前提真值枚举：'+x.premise.total_assignments+'种确定赋值；TRUE '+x.premise.solution_count+'种，FALSE '+x.premise.false_count+'种。');
   row(final,'完成关系 '+({IFF:'C ↔ K',SUFFICIENT:'K ⇒ C',NECESSARY:'C ⇒ K'}[x.direction]??x.direction)+'：'+x.completion_relation.total_assignments+'种赋值；满足 '+x.completion_relation.solution_count+'种，违反 '+x.completion_relation.violation_count+'种。计数不是准确率或发生概率。');
   const table=el('table'),head=el('tr');for(const title of [...x.premise.variables.map(id=>meanings.get(id)??id),'K'])head.append(el('th',title));table.append(head);
   for(let mask=0;mask<x.premise.membership.length;mask++){const tr=el('tr');for(let bit=0;bit<x.premise.variables.length;bit++)tr.append(el('td',String((mask>>(x.premise.variables.length-bit-1))&1)));tr.append(el('td',x.premise.membership[mask]));table.append(tr);}final.append(table);
  }
  row(final,'显式依赖图：'+math.dependency.edges.length+'条边；环集合 '+(math.dependency.cycles.length?'非空':'∅')+'。成功状态门保留在每条边的表达式中。',math.dependency.proof.sources);
  for(const a of math.boundary_atoms.negative)row(final,'禁止域：'+a.operation+' × {'+a.operands.map(x=>x.label).join('、')+'}；'+(a.conditions.length?'条件 '+a.conditions.map(x=>x.expression_id).join('、'):'无条件')+'；'+name(a.owner_id),a.sources);
  row(final,'已证明冲突 '+math.conflicts.length+'项；待定比较及事实 '+math.unknown_frontier.length+'项；未支持计算 '+math.coverage.unsupported_count+'项。没有冲突证明不等于全部比较已经证明一致。');
  row(final,'布尔分项求解：'+(states[math.boolean.result]??math.boolean.result??'未确定')+'。联合执行可行性未证明；计算不签发业务授权。');
  if(math.unknown_frontier.length){const pending=section('数学计算中的待定比较：具体缺少什么证明');for(const x of math.unknown_frontier)row(pending,(x.left_atom?name(x.left_atom)+' ↔ '+name(x.right_atom):name(x.fact_id))+'：'+x.reason,x.proof?.sources??x.sources);}
 }else container.append(el('p','此历史结果未保存新版数学结果报告；没有自动重算或补造。'));
 container.append(el('p',states[c.status]??c.status),el('p','输入来自同一次IR；程序计算，不再调用LLM。可行组合不是实际完成，技术接受与计算均不构成业务授权。'));
 container.append(el('p','原文覆盖缺口 '+c.coverage.source_gaps+'；未决事实 '+c.coverage.unresolved_facts+'；尚未证明全部BXP符合性。'));
 const b=section('1. 条件与义务的布尔一致性');
 row(b,states[c.boolean.result]??states[c.boolean.status]??c.boolean.status);
 for(const x of c.boolean.components??[])if(x.status==='UNSUPPORTED')row(b,'未完成分量：'+x.reason+'；变量数 '+x.variables.length);
 for(const x of c.boolean.formulas)row(b,formula(x.formula),x.sources);
 const q=section('2. 数量限制与区间交集');
 const comparator={EQ:'=',LT:'<',LTE:'≤',GT:'>',GTE:'≥'};
 for(const x of c.quantities){
  const mode=x.distribution??x.quantity.distribution?.mode;
  row(q,name(x.quantity.target_id)+'：'+(mode==='EACH'?'每个成员分别满足；':mode==='AGGREGATE'?'集合合计满足；':'')+x.quantity.metric+' '+comparator[x.quantity.comparator]+' '+x.quantity.value+' '+x.quantity.unit+'；计数范围 '+name(x.quantity.count_scope)+(x.domain_id?'；成员域 '+x.domain_id:'')+(x.quantity.use==='WORK_PLAN'?'；计划安排，不是资源配额':'')+'；实际核验 '+(states[x.result]??x.result),x.sources);
  for(const member of x.members??[])row(q,'成员 '+name(member.member_id)+'：'+(states[member.result]??member.result),x.sources);
 }
 for(const x of c.intervals)row(q,'目标 '+name(x.subject)+'：合并下界 '+(x.lower?(x.lower.inclusive?'≥ ':'> ')+x.lower.value:'未设定')+'，上界 '+(x.upper?(x.upper.inclusive?'≤ ':'< ')+x.upper.value:'未设定')+' '+x.unit+'；'+(x.empty?'空区间，存在冲突':'区间非空，不代表实际已满足'),x.input_constraints.flatMap(v=>v.sources));
 if(!c.quantities.length)row(q,'没有已表达的数量约束。');
 const p=section('3. 条件、完成和停止的当前值');
 for(const x of c.conditions){
  row(p,name(x.target_id)+'；方向 '+({NECESSARY:'必要前提',SUFFICIENT:'充分触发',IFF:'充要条件',ORDER:'纯先后'})[x.direction]+'；'+(x.temporal==='AFTER'?'之后':x.temporal==='BEFORE'?'之前':'无时间先后')+'；前提当前值 '+(states[x.condition_value]??x.condition_value),x.sources);
  if(x.assessment){const a=x.assessment;row(p,'结果观测：'+(states[a.observed_outcome]??a.observed_outcome)+'；逻辑条件核验：'+(a.logical_result==='TRUE'?'本条逻辑条件满足':a.logical_result==='FALSE'?'观测违反本条逻辑条件':'未知，尚不能判断')+(a.temporal_result==='UNKNOWN'?'；实际先后尚需时间观测':'')+'。条件满足不证明动作已执行，不产生执行许可。',x.sources);}
 }
 if(!c.conditions.length)row(p,'没有已表达的条件或根任务转换。');
 const d=section('4. 明确阶段／事件先后与循环检查');
 row(d,'显式先后 '+c.dependency.prerequisite_edges+' 条；循环 '+c.dependency.cycles.length+' 个。产物可用性不会被改成整项事件先后。');
 for(const x of c.dependency.edges)row(d,name(x.from)+' → '+name(x.to),x.sources);
 for(const x of c.dependency.conditional_edges)row(d,'条件分支保留：'+name(x.from)+' → '+name(x.to)+'；未并入无条件先后图',x.sources);
 const s=section('5. 对象范围与产物可用性');
 for(const x of c.ranges)row(s,'范围目标 '+name(x.target_id)+'：'+(x.members?x.members.map(name).join('、'):states[x.result]??x.result)+'；范围外不等于获得许可',x.sources);
 for(const x of c.availability)row(s,name(x.artifact_id)+' → '+name(x.consumer_event_id)+'；要求 '+(x.availability==='COMPLETE_RESULT'?'完整结果可用':'被使用部分可用')+'；当前 '+(states[x.result]??x.result),x.sources);
 if(!c.ranges.length&&!c.availability.length)row(s,'没有已表达的可计算范围或产物可用性依赖。');
 if(c.conflicts.length){const conflicts=section('计算发现的冲突');for(const x of c.conflicts)row(conflicts,JSON.stringify(x));}
 if(c.unsupported.length){const u=section('未计算项目：不计为通过');for(const x of c.unsupported)row(u,x.fact_id+'：'+x.reason,x.sources);}
 const raw=el('details');raw.append(el('summary','开发详情：计算JSON'),el('pre',JSON.stringify(c,null,2)));container.append(raw);
 if(onObserve){
  const form=el('form');form.append(el('h3','输入实际观测，重新核对边界'),el('p','这些值由你提供，不是模型判断或程序采集的事实。未知留空。每次重算另存记录，原文、语义、7+1与原计算不变；不调用模型。'));
  const fields=[];
  const choice=(label,key,id,metadata={})=>{const line=el('label',label+' '),select=el('select');for(const [value,text]of [['','未知'],['true','是／成立'],['false','否／不成立']]){const o=el('option',text);o.value=value;select.append(o);}line.append(select);form.append(line,el('br'));fields.push({key,id,select,metadata});};
  for(const x of trace.ir.expressions.filter(x=>x.op==='STATE'))choice('状态：'+x.state.predicate+'（'+x.state.args.map(name).join('、')+'）'+(x.state.polarity==='NEGATIVE'?'；本条否定状态是否成立':''),'states',x.id);
  for(const x of c.conditions.filter(x=>x.assessment?.status==='CHECKED'))choice('结果：'+name(x.assessment.target_id)+'；'+({TASK_COMPLETE:'任务是否完成',TASK_STOP:'任务是否停止',EVENT_STATE:'事件状态是否成立',EVENT_EXECUTED:'动作是否已发生',OUTPUT_BEHAVIOR:'输出行为是否成立'}[x.assessment.outcome_kind]??x.assessment.outcome_kind),'outcomes',x.claim_id,{target_id:x.assessment.target_id,kind:x.assessment.outcome_kind,known:true});
  for(const x of c.quantities.filter(x=>x.quantity.distribution?.mode!=='EACH')){const line=el('label','实际数量：'+name(x.quantity.target_id)+' '+x.quantity.metric+'（'+x.quantity.unit+'） '),input=el('input');input.type='number';input.step='any';line.append(input);form.append(line,el('br'));fields.push({key:'quantities',id:x.claim_id,select:input,metadata:{target_id:x.quantity.target_id,count_scope:x.quantity.count_scope,unit:x.quantity.unit}});}
  const button=el('button','仅重算，不调用LLM');button.type='submit';const message=el('p'),resultBox=el('section');
  form.append(button,message,resultBox);form.onsubmit=async e=>{e.preventDefault();button.disabled=true;try{const input={states:{},outcomes:{},quantities:{}};for(const f of fields){if(f.select.value==='')continue;const value=f.key==='quantities'?Number(f.select.value):f.select.value==='true';input[f.key][f.id]=f.key==='states'?value:{...f.metadata,value};}const result=await onObserve(input);message.textContent='已保存观测 '+result.observation_id+'；用户自报，未独立验证。';renderBoundaryCalculations(resultBox,{...trace,boundary_calculations:result.calculation},onEvidence);const a=el('a','下载本次观测与计算');a.href=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json'}));a.download=result.observation_id+'.json';resultBox.append(a);}catch(error){message.textContent='未接受本次观测：'+error.message;}finally{button.disabled=false;}};
  container.append(form);
 }
 if(container.dataset.runId){const download=el('a','导出原编译的完整计算JSON');download.href='/api/runs/'+container.dataset.runId+'/calculations.json';download.download='';container.append(download);}
}
