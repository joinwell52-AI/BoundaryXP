// Read the saved program result. No model calls, source parsing or computation.
const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
const states={PARTIAL:'部分计算：存在缺口',CONFLICT:'发现约束冲突',CALCULATED_FRAGMENT:'受支持的明确约束已计算',UNKNOWN:'未知：未提供运行观测',TRUE:'成立',FALSE:'不成立',satisfiable:'存在可行组合',unsatisfiable:'不存在可行组合',NOT_APPLICABLE:'没有此类明确计算项',CALCULATED:'已计算',UNSUPPORTED:'超出受支持计算范围'};
export function renderBoundaryCalculations(container,trace,onEvidence=()=>{}){
 container.replaceChildren();container.append(el('h2','最后一步：程序边界计算'));
 const c=trace?.boundary_calculations;
 if(!c){container.append(el('p',trace?'此历史记录没有保存本版计算阶段；未重算、未补造。':'等待IR与固定7+1生成后，计算程序直接消费同一IR。'));return;}
 const labels=new Map((trace.ir.entities??[]).map(x=>[x.id,x.label]));labels.set('ROOT','根任务');
 for(const f of trace.ir.facts.filter(x=>x.kind==='EVENT'))labels.set(f.event.id,f.event.predicate+'（'+(f.roles??[]).map(r=>(r.role==='PERFORMER'?'执行者：':'')+(r.entity?.label??r.entity_id)).join('、')+'）');
 const name=id=>labels.get(id)??id;
 const atoms=new Map(c.boolean.atoms.map(x=>[x.id,x.meaning]));
 const atomText=a=>a?.kind==='PROPERTY_TEST'?name(a.test.target_id)+(a.test.property_path.length?'.'+a.test.property_path.join('.'):'')+' '+a.test.operator+' '+JSON.stringify(a.test.value):a?.kind==='OUTPUT_BEHAVIOR'?'产物 '+name(a.artifact_id)+' 的内部行为 '+name(a.event_id):a?.kind==='STATE'?a.predicate+'('+a.args.map(name).join('、')+')':a?.event_id?'执行 '+name(a.event_id):a?.kind==='TASK_COMPLETE'?'任务完成':a?.kind==='TASK_STOP'?'任务停止':null;
 const formula=x=>typeof x==='boolean'?String(x):x.var?(atomText(atoms.get(x.var))??x.var):x.not?'非('+formula(x.not)+')':x.all?'('+x.all.map(formula).join(' 且 ')+')':x.any?'('+x.any.map(formula).join(' 或 ')+')':x.implies?'('+formula(x.implies[0])+' ⇒ '+formula(x.implies[1])+')':'未支持表达式';
 const row=(section,text,sources)=>{const p=el('p',text);if(sources?.length){const button=el('button','查看本条原文依据');button.className='secondary';button.onclick=()=>onEvidence(sources);p.append(document.createTextNode(' '),button);}section.append(p);};
 const section=title=>{const d=el('details');d.open=true;d.append(el('summary',title));container.append(d);return d;};
 container.append(el('p',states[c.status]??c.status),el('p','输入来自同一次IR；程序计算，不再调用LLM。可行组合不是实际完成，技术接受与计算均不构成业务授权。'));
 container.append(el('p','原文覆盖缺口 '+c.coverage.source_gaps+'；未决事实 '+c.coverage.unresolved_facts+'；尚未证明全部BXP符合性。'));
 const b=section('1. 条件与义务的布尔一致性');
 row(b,states[c.boolean.result]??states[c.boolean.status]??c.boolean.status);
 for(const x of c.boolean.components??[])if(x.status==='UNSUPPORTED')row(b,'未完成分量：'+x.reason+'；变量数 '+x.variables.length);
 for(const x of c.boolean.formulas)row(b,formula(x.formula),x.sources);
 const q=section('2. 数量限制与区间交集');
 const comparator={EQ:'=',LT:'<',LTE:'≤',GT:'>',GTE:'≥'};
 for(const x of c.quantities){
  const mode=x.distribution??x.quantity.distribution?.mode;
  row(q,name(x.quantity.target_id)+'：'+(mode==='EACH'?'每个成员分别满足；':mode==='AGGREGATE'?'集合合计满足；':'')+x.quantity.metric+' '+comparator[x.quantity.comparator]+' '+x.quantity.value+' '+x.quantity.unit+'；计数范围 '+name(x.quantity.count_scope)+(x.domain_id?'；成员域 '+x.domain_id:'')+(x.quantity.use==='WORK_PLAN'?'；计划安排，不是资源配额':'')+'；实际核验 '+(states[x.result]??x.result),x.sources);
  for(const member of x.members??[])row(q,'成员 '+name(member.member_id)+'：'+(states[member.result]??member.result),x.sources);
 }
 for(const x of c.intervals)row(q,'目标 '+name(x.subject)+'：合并下界 '+(x.lower?(x.lower.inclusive?'≥ ':'> ')+x.lower.value:'未设定')+'，上界 '+(x.upper?(x.upper.inclusive?'≤ ':'< ')+x.upper.value:'未设定')+' '+x.unit+'；'+(x.empty?'空区间，存在冲突':'区间非空，不代表实际已满足'),x.input_constraints.flatMap(v=>v.sources));
 if(!c.quantities.length)row(q,'没有已表达的数量约束。');
 const p=section('3. 条件、完成和停止的当前值');
 for(const x of c.conditions)row(p,name(x.target_id)+'；方向 '+({NECESSARY:'必要前提',SUFFICIENT:'充分触发',IFF:'充要条件',ORDER:'纯先后'})[x.direction]+'；'+(x.temporal==='AFTER'?'之后':x.temporal==='BEFORE'?'之前':'无时间先后')+'；前提当前值 '+(states[x.condition_value]??x.condition_value),x.sources);
 if(!c.conditions.length)row(p,'没有已表达的条件或根任务转换。');
 const d=section('4. 明确阶段／事件先后与循环检查');
 row(d,'显式先后 '+c.dependency.prerequisite_edges+' 条；循环 '+c.dependency.cycles.length+' 个。产物可用性不会被改成整项事件先后。');
 for(const x of c.dependency.edges)row(d,name(x.from)+' → '+name(x.to),x.sources);
 for(const x of c.dependency.conditional_edges)row(d,'条件分支保留：'+name(x.from)+' → '+name(x.to)+'；未并入无条件先后图',x.sources);
 const s=section('5. 对象范围与产物可用性');
 for(const x of c.ranges)row(s,'范围目标 '+name(x.target_id)+'：'+(x.members?x.members.map(name).join('、'):states[x.result]??x.result)+'；范围外不等于获得许可',x.sources);
 for(const x of c.availability)row(s,name(x.artifact_id)+' → '+name(x.consumer_event_id)+'；要求 '+(x.availability==='COMPLETE_RESULT'?'完整结果可用':'被使用部分可用')+'；当前 '+(states[x.result]??x.result),x.sources);
 if(!c.ranges.length&&!c.availability.length)row(s,'没有已表达的可计算范围或产物可用性依赖。');
 if(c.conflicts.length){const conflicts=section('计算发现的冲突');for(const x of c.conflicts)row(conflicts,JSON.stringify(x));}
 if(c.unsupported.length){const u=section('未计算项目：不计为通过');for(const x of c.unsupported)row(u,x.fact_id+'：'+x.reason,x.sources);}
 const raw=el('details');raw.append(el('summary','开发详情：计算JSON'),el('pre',JSON.stringify(c,null,2)));container.append(raw);
 const download=el('a','导出本次完整计算JSON');download.href='/api/runs/'+container.dataset.runId+'/calculations.json';download.download='';container.append(download);
}
