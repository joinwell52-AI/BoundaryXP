// Finite abstract joint solving. No source text, model, network or business execution.
import {validateBooleanConstraints,evaluateBooleanAssignment} from './boolean-solver.mjs';
import {compareDecimal} from './decimal.mjs';
const variablesOf=f=>typeof f==='boolean'?[]:f.var?[f.var]:'not' in f?variablesOf(f.not):Object.values(f)[0].flatMap(variablesOf);
const partial=(f,v)=>{if(typeof f==='boolean')return f;if(f.var)return v[f.var];if('not' in f){const a=partial(f.not,v);return a===undefined?undefined:!a;}if(f.implies){const a=partial(f.implies[0],v),b=partial(f.implies[1],v);return a===false||b===true?true:a===true&&b===false?false:undefined;}const a=(f.all??f.any).map(x=>partial(x,v));return f.all?a.includes(false)?false:a.every(x=>x===true)?true:undefined:a.includes(true)?true:a.every(x=>x===false)?false:undefined;};
const decimal=s=>{if(!/^-?\d+(\.\d+)?$/.test(s))throw Error('NON_DECIMAL_BOUND');const [a,b='']=s.split('.');return {n:BigInt(a+b),scale:b.length};};
const text=(n,scale)=>{const sign=n<0n?'-':'';let s=(n<0n?-n:n).toString().padStart(scale+1,'0');return sign+(scale?s.slice(0,-scale)+'.'+s.slice(-scale):s);};
function midpoint(a,b){const x=decimal(a),y=decimal(b),scale=Math.max(x.scale,y.scale),n=x.n*10n**BigInt(scale-x.scale)+y.n*10n**BigInt(scale-y.scale);return text(n*5n,scale+1);}
function shift(a,n){const x=decimal(a);return text(x.n+BigInt(n)*10n**BigInt(x.scale),x.scale);}
function intervalValue(x){if(x.empty)return null;if(x.upper?.inclusive)return x.upper.value;if(x.lower?.inclusive)return x.lower.value;if(x.lower&&x.upper)return midpoint(x.lower.value,x.upper.value);if(x.lower)return shift(x.lower.value,1);if(x.upper)return shift(x.upper.value,-1);return '0';}
function intervalContains(x,v){return (!x.lower||compareDecimal(v,x.lower.value)>0||x.lower.inclusive&&compareDecimal(v,x.lower.value)===0)&&(!x.upper||compareDecimal(v,x.upper.value)<0||x.upper.inclusive&&compareDecimal(v,x.upper.value)===0);}
function temporalEmbedding(problem,numeric,ranks){const schedules={};for(const h of problem.temporal_horizons??[]){const bound=problem.intervals.find(x=>x.id===h.interval_id);if(!bound)throw Error('TEMPORAL_HORIZON_BINDING');let value=numeric[h.interval_id],max=Math.max(0,...Object.values(ranks));if(max>0&&compareDecimal(value,'0')<=0){if(bound.upper&&compareDecimal(bound.upper.value,'0')<=0)return null;value=bound.upper?midpoint('0',bound.upper.value):shift(bound.lower?.value??'0',1);if(!intervalContains(bound,value))return null;numeric[h.interval_id]=value;}
 const d=decimal(value),den=10n**BigInt(d.scale)*BigInt(max+1);schedules[h.interval_id]={duration:value,unit:h.unit,origin:'0',points:Object.fromEntries(Object.entries(ranks).map(([id,rank])=>[id,{numerator:(BigInt(rank)*d.n).toString(),denominator:den.toString()}])),interpretation:'Constructive abstract time assignment; not predicted/observed durations'};}return schedules;}
function activeEdges(p,values){return p.orders.filter(x=>!x.guard||partial(x.guard,values)===true);}
function ranking(edges){const nodes=[...new Set(edges.flatMap(x=>[x.from,x.to]))].sort(),rank={},pending=new Set(nodes);while(pending.size){const ready=[...pending].filter(n=>edges.filter(e=>e.to===n).every(e=>!pending.has(e.from))).sort();if(!ready.length)return null;for(const n of ready){rank[n]=Math.max(0,...edges.filter(e=>e.to===n).map(e=>rank[e.from]+1));pending.delete(n);}}return rank;}
export function verifyJointWitness(problem,witness){
 const checks=[];const add=(id,pass,kind)=>checks.push({id,pass,kind});
 add('EXACT_VARIABLE_ASSIGNMENT',Object.keys(witness.boolean).length===problem.variables.length&&problem.variables.every(v=>typeof witness.boolean[v]==='boolean'),'BINDING');
 for(const c of problem.constraints){const vars=[...new Set(variablesOf(c.formula))];let pass=false;try{pass=evaluateBooleanAssignment(vars,c.formula,Object.fromEntries(vars.map(v=>[v,witness.boolean[v]])));}catch{}add(c.id,pass,'BOOLEAN');}
 for(const x of problem.intervals)add('interval:'+x.id,typeof witness.intervals[x.id]==='string'&&intervalContains(x,witness.intervals[x.id]),'INTERVAL');
 for(const x of activeEdges(problem,witness.boolean))add('order:'+x.id,Number.isSafeInteger(witness.order_rank[x.from])&&Number.isSafeInteger(witness.order_rank[x.to])&&witness.order_rank[x.from]<witness.order_rank[x.to],'ABSTRACT_ORDER');
 for(const h of problem.temporal_horizons??[]){const schedule=witness.metric_schedule?.[h.interval_id],duration=witness.intervals[h.interval_id];let valid=!!schedule&&schedule.duration===duration&&schedule.unit===h.unit;
  if(valid){try{const d=decimal(duration),scale=10n**BigInt(d.scale);for(const id of Object.keys(witness.order_rank)){const p=schedule.points[id];const n=BigInt(p.numerator),den=BigInt(p.denominator);if(den<=0n||n<0n||n*scale>d.n*den)valid=false;}for(const e of activeEdges(problem,witness.boolean)){const a=schedule.points[e.from],b=schedule.points[e.to];if(BigInt(a.numerator)*BigInt(b.denominator)>=BigInt(b.numerator)*BigInt(a.denominator))valid=false;}}catch{valid=false;}}
  add('temporal-horizon:'+h.interval_id,valid,'TOTAL_DURATION_EMBEDDING');
 }
 return {valid:checks.every(x=>x.pass),checks};
}
export function solveJointBoundary(problem,{maxNodes=100000}={}){
 if(!Array.isArray(problem.variables)||problem.variables.length>128||new Set(problem.variables).size!==problem.variables.length||problem.constraints.length>1024||problem.orders.length>1024||!Number.isSafeInteger(maxNodes)||maxNodes<1)throw Error('JOINT_CAPACITY_OR_SIGNATURE');
 const declared=new Set(problem.variables);
 for(const c of problem.constraints){const vars=[...new Set(variablesOf(c.formula))];if(vars.some(v=>!declared.has(v)))throw Error('JOINT_DANGLING_VARIABLE');validateBooleanConstraints(vars,[c.formula]);}
 for(const e of problem.orders)if(e.guard){const vars=[...new Set(variablesOf(e.guard))];if(vars.some(v=>!declared.has(v)))throw Error('ORDER_DANGLING_VARIABLE');validateBooleanConstraints(vars,[e.guard]);}
 const numeric=Object.fromEntries(problem.intervals.map(x=>[x.id,intervalValue(x)]));if(Object.values(numeric).includes(null))return {result:'unsatisfiable',reason:'EMPTY_INTERVAL',witness:null};
 const frequency=new Map(problem.variables.map(v=>[v,0]));for(const c of problem.constraints)for(const v of new Set(variablesOf(c.formula)))frequency.set(v,frequency.get(v)+1);
 const ordered=[...problem.variables].sort((a,b)=>frequency.get(b)-frequency.get(a)||a.localeCompare(b));let nodes=0,limited=false;
 const search=values=>{if(++nodes>maxNodes){limited=true;return null;}if(problem.constraints.some(c=>partial(c.formula,values)===false))return null;
  if(ordered.every(v=>values[v]!==undefined)){const ranks=ranking(activeEdges(problem,values));if(!ranks)return null;const intervals={...numeric},metric_schedule=temporalEmbedding(problem,intervals,ranks);return metric_schedule?{boolean:{...values},intervals,order_rank:ranks,metric_schedule}:null;}
  const v=ordered.find(v=>values[v]===undefined);for(const value of [false,true]){const found=search({...values,[v]:value});if(found)return found;if(limited)return null;}return null;};
 const witness=search({});if(limited)return {result:'unknown',reason:'SEARCH_CAPACITY',nodes,witness:null};if(!witness)return {result:'unsatisfiable',reason:'BOOLEAN_OR_ACTIVE_ORDER',nodes,witness:null};
 const verification=verifyJointWitness(problem,witness);if(!verification.valid)throw Error('JOINT_WITNESS_VERIFICATION_FAILED');return {result:'satisfiable',nodes,witness,verification,proof_scope:'FINITE_DECLARED_BOOLEAN_INTERVAL_AND_ABSTRACT_ORDER'};
}
