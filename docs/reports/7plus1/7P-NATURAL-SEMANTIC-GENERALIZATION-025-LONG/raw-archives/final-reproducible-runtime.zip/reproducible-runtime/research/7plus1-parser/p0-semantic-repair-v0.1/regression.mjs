import fs from 'node:fs';import {spawn} from 'node:child_process';
const base=new URL('./',import.meta.url),log=fs.createWriteStream(new URL('FULL-REGRESSION.log',base),{flags:'wx'}),started=new Date().toISOString();
const child=spawn('cmd.exe',['/d','/s','/c','npm test'],{cwd:new URL('../../../',base),windowsHide:true,stdio:['ignore','pipe','pipe']});let output='';
for(const stream of [child.stdout,child.stderr])stream.on('data',data=>{output+=data;log.write(data);});
child.on('close',code=>{log.end();const summary={command:'npm test',working_directory:'D:\\boundx',started,finished:new Date().toISOString(),exit_code:code,tests:Number(output.match(/\btests (\d+)/u)?.[1]),pass:Number(output.match(/\bpass (\d+)/u)?.[1]),fail:Number(output.match(/\bfail (\d+)/u)?.[1]),skipped:Number(output.match(/\bskipped (\d+)/u)?.[1])};fs.writeFileSync(new URL('FULL-REGRESSION.json',base),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(summary));process.exitCode=code;});
