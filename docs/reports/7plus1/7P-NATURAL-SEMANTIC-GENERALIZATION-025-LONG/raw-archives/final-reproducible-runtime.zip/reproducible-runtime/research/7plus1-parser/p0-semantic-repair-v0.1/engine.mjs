import {performance} from 'node:perf_hooks';
import {sourceDocument} from './source.mjs';import {analyze} from './linguistic.mjs';import {buildFrames} from './frames.mjs';import {project} from './projection.mjs';import {normalize} from './normalization.mjs';
export async function parse7Plus1(input,metadata={}){
 const start=performance.now(),doc=sourceDocument(input,metadata),structure_ms=performance.now()-start;
 const signals=await analyze(doc),gstart=performance.now(),semantic=buildFrames(doc,signals),gsg_ms=performance.now()-gstart;
 const normalization=await normalize(semantic),pstart=performance.now(),projection=project(semantic),projection_ms=performance.now()-pstart;
 const points=[...doc.source.raw_text];let evidence_count=0;
 for(const slot of Object.values(projection.slots))for(const entry of slot.entries){if(!entry.evidence.length)throw Error('ENTRY_WITHOUT_EVIDENCE');for(const e of entry.evidence){const s=e.source_span;if(s.source_id!==doc.source.source_id||s.start<0||s.end>points.length||points.slice(s.start,s.end).join('')!==s.quote)throw Error('PROVENANCE_MISMATCH');evidence_count++;}}
 return {parser_revision:'p0-semantic-repair-v0.1',parser_status:semantic.diagnostics.length?'PARSER_COVERAGE_FAILURE':normalization.diagnostics.length?'NORMALIZATION_DEGRADED':'PARSED',source:doc.source,structure:doc.structure,signals,...semantic,...projection,normalization,performance:{total_ms:performance.now()-start,structure_ms,nlp_ms:signals.metrics.nlp_ms,gsg_ms,projection_ms,frame_count:semantic.frames.length,...normalization.metrics,model_load_count:signals.metrics.model_load_count+normalization.metrics.model_load_count,linguistic_model_load_count:signals.metrics.model_load_count},provenance:{evidence_count,valid:true},pipeline_counts:{clauses:signals.clauses.length,frames:semantic.frames.length,entries:Object.values(projection.slots).reduce((n,s)=>n+s.entries.length,0)}};
}
