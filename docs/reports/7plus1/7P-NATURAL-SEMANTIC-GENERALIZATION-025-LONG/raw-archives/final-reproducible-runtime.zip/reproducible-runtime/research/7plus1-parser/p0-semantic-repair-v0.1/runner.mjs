import fs from 'node:fs';import path from 'node:path';import {randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {parse7Plus1} from './engine.mjs';import {hash} from './source.mjs';
export const BASE=path.dirname(fileURLToPath(import.meta.url));
export const ROOT=path.resolve(BASE,'../../..');
export async function runParser(bytes,options={}){
 const id=new Date().toISOString().replace(/[:.]/g,'-')+'-'+randomUUID().slice(0,8),dir=path.join(BASE,'runs',id);fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(path.join(dir,'SOURCE.txt'),bytes,{flag:'wx'});
 const result=await parse7Plus1(bytes,options);fs.writeFileSync(path.join(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 const manifest={run_id:id,parser_revision:'p0-semantic-repair-v0.1',files:Object.fromEntries(['SOURCE.txt','RESULT.json'].map(n=>[n,hash(fs.readFileSync(path.join(dir,n)))]))};fs.writeFileSync(path.join(dir,'MANIFEST.json'),JSON.stringify(manifest,null,2),{flag:'wx'});return {run_id:id,output_directory:dir,result};
}
