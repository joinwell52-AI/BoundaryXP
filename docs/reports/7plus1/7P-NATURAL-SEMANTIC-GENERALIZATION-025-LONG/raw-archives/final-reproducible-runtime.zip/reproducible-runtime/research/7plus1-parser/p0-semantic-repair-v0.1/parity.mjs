import fs from 'node:fs';import path from 'node:path';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';import {hash} from './source.mjs';
const BASE=path.dirname(fileURLToPath(import.meta.url)),uiIds=['2026-09-28T15-39-25-051Z-fa9b1fb5','2026-09-28T15-40-38-533Z-845ff2d4'],checks=[];
for(const [i,id] of ['T1','T2'].entries()){
 const input=path.join(BASE,id+'-INPUT.txt');let output='',errors='';const child=spawn(process.execPath,[path.join(BASE,'cli.mjs'),'--input',input],{cwd:path.resolve(BASE,'../../..'),windowsHide:true});child.stdout.on('data',b=>output+=b);child.stderr.on('data',b=>errors+=b);const code=await new Promise(resolve=>child.on('close',resolve));
 fs.writeFileSync(path.join(BASE,id+'-CLI-EXECUTION.json'),JSON.stringify({command:[process.execPath,path.join(BASE,'cli.mjs'),'--input',input],exit_code:code,stdout:output,stderr:errors},null,2),{flag:'wx'});
 const cli=JSON.parse(output),a=JSON.parse(fs.readFileSync(path.join(cli.output_directory,'RESULT.json'))),b=JSON.parse(fs.readFileSync(path.join(BASE,'runs',uiIds[i],'RESULT.json')));
 checks.push({case:id,cli_run_id:cli.run_id,ui_run_id:uiIds[i],source_sha256:a.source.sha256,source_equal:a.source.sha256===b.source.sha256,slots_equal:JSON.stringify(a.slots)===JSON.stringify(b.slots),frames_equal:JSON.stringify(a.frames)===JSON.stringify(b.frames),cli_exit_code:code,cli_slot_digest:hash(a.slots),ui_slot_digest:hash(b.slots)});
}
const report={status:checks.every(x=>x.slots_equal&&x.frames_equal&&x.source_equal&&x.cli_exit_code===0)?'PASS':'FAIL',semantic_divergence:checks.filter(x=>!x.slots_equal||!x.frames_equal).length,checks};fs.writeFileSync(path.join(BASE,'CLI-UI-PARITY.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(report);
