import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {randomUUID} from 'node:crypto';import {pathToFileURL} from 'node:url';
import {BASE,runParser} from './runner.mjs';import {hash} from './source.mjs';
import {analyze,closeNlp} from './linguistic.mjs';import {sourceDocument} from './source.mjs';import {warmSemantic} from './normalization.mjs';
export async function warmup(){const linguistic=await analyze(sourceDocument('准备。Ready.'));const semantic=await warmSemantic();return {linguistic:linguistic.models,semantic};}
export function createServer(){let busy=false;return http.createServer(async(req,res)=>{
 const send=(code,obj)=>{res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj));};
 try{
 const host=req.headers.host,port=req.socket.localPort;if(!['127.0.0.1:'+port,'localhost:'+port].includes(host))return send(403,{error:'LOCALHOST_ONLY'});
 if(req.headers.origin&&req.headers.origin!=='http://'+host)return send(403,{error:'SAME_ORIGIN_REQUIRED'});
 const url=new URL(req.url,'http://'+host);
 if(req.method==='GET'&&['/','/app.js','/style.css'].includes(url.pathname)){const name=url.pathname==='/'?'index.html':url.pathname.slice(1);res.writeHead(200,{'content-type':name.endsWith('.html')?'text/html; charset=utf-8':name.endsWith('.js')?'text/javascript; charset=utf-8':'text/css; charset=utf-8','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; frame-ancestors 'none'"});return res.end(fs.readFileSync(path.join(BASE,'web',name)));}
 if(req.method==='GET'&&url.pathname==='/api/runs'){const dir=path.join(BASE,'runs');const runs=fs.existsSync(dir)?fs.readdirSync(dir).filter(id=>fs.existsSync(path.join(dir,id,'MANIFEST.json'))).sort().reverse():[];return send(200,runs);}
 if(req.method==='GET'&&url.pathname.startsWith('/api/runs/')){const id=url.pathname.slice(10);if(!/^[\w.-]+$/u.test(id))return send(400,{error:'INVALID_ID'});const dir=path.join(BASE,'runs',id),m=JSON.parse(fs.readFileSync(path.join(dir,'MANIFEST.json'),'utf8')),raw=fs.readFileSync(path.join(dir,'RESULT.json'));if(hash(raw)!==m.files['RESULT.json'])throw Error('RUN_INTEGRITY');return send(200,{run_id:id,result:JSON.parse(raw)});}
 if(req.method==='POST'&&['/api/parse','/api/review'].includes(url.pathname)){
  const chunks=[];let size=0;for await(const part of req){size+=part.length;if(size>2*1024*1024)return send(413,{error:'MAX_INPUT_SIZE'});chunks.push(part);}const input=JSON.parse(Buffer.concat(chunks).toString('utf8'));
  if(url.pathname==='/api/review'){if(typeof input.run_id!=='string'||!/^[\w.-]+$/u.test(input.run_id)||!fs.existsSync(path.join(BASE,'runs',input.run_id,'MANIFEST.json')))return send(400,{error:'UNKNOWN_RUN'});if(typeof input.notes!=='string'||input.notes.length>20000)return send(400,{error:'INVALID_REVIEW'});const dir=path.join(BASE,'reviews');fs.mkdirSync(dir,{recursive:true});const id=randomUUID()+'.json';fs.writeFileSync(path.join(dir,id),JSON.stringify({run_id:input.run_id,notes:input.notes,timestamp:new Date().toISOString()},null,2),{flag:'wx'});return send(201,{file:id});}
  if(busy)return send(409,{error:'PARSER_BUSY'});if(typeof input.text!=='string'&&typeof input.base64!=='string')return send(400,{error:'TEXT_REQUIRED'});
  busy=true;try{const bytes=input.base64!==undefined?Buffer.from(input.base64,'base64'):Buffer.from(input.text,'utf8');const r=await runParser(bytes,{filename:input.filename??'task.txt'});return send(200,r);}finally{busy=false;}
 }return send(404,{error:'NOT_FOUND'});
 }catch(e){send(500,{error:e.message});}
 });}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const port=Number(process.env.BOUNDARYXP_PARSER_PORT??58618);console.log('Warming local NLP / retrieval / NLI models…');try{const proof=await warmup();fs.mkdirSync(path.join(BASE,'runtime'),{recursive:true});fs.writeFileSync(path.join(BASE,'runtime','warmup-'+Date.now()+'.json'),JSON.stringify(proof,null,2),{flag:'wx'});createServer().listen(port,'127.0.0.1',()=>console.log('BoundaryXP Parser P0 repair: http://127.0.0.1:'+port));}catch(e){closeNlp();throw e;}}
