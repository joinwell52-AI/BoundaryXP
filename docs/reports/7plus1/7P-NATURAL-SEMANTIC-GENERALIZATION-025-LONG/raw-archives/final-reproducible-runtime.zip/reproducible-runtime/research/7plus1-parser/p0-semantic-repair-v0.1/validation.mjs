import fs from 'node:fs';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {parse7Plus1} from './engine.mjs';import {closeNlp,lexical} from './linguistic.mjs';import {sourceDocument} from './source.mjs';import {warmup} from './server.mjs';
const BASE=new URL('./',import.meta.url),load=n=>JSON.parse(fs.readFileSync(new URL(n,BASE),'utf8'));
export async function evaluate({write=false}={}){
 const expected=load('design-baseline/EXPECTED-SEMANTICS-T1-T2.json'),results={},checks=[];
 const check=(name,condition)=>{checks.push({name,pass:Boolean(condition)});};
 const warm=await warmup();
 for(const id of ['T1','T2'])results[id]=await parse7Plus1(expected[id].text);
 const {T1,T2}=results,entries=(r,s)=>r.slots[s].entries,display=(r,s)=>entries(r,s).map(e=>e.display),entity=(r,s)=>entries(r,s).map(e=>e.value.entity),action=(r,p)=>entries(r,'A').filter(e=>e.value.action===p);
 for(const id of ['T1','T2'])for(const [s,want] of Object.entries(expected[id].slots))check(id+' status '+s,results[id].slots[s].status===want.status);
 check('T1 exact I objects',JSON.stringify(entity(T1,'I'))===JSON.stringify(expected.T1.slots.I.must_include));
 check('T1 exact positive actions',JSON.stringify(display(T1,'A'))===JSON.stringify(expected.T1.slots.A.must_include));
 check('T1 no escalation / condition invented',T1.frames.every(f=>f.kind!=='ESCALATION'&&f.condition.length===0));
 check('T1 participants',JSON.stringify(entries(T1,'P').map(e=>e.value.participant))===JSON.stringify(['PM','admin']));
 check('T2 exact I objects including guarded backup',JSON.stringify(entity(T2,'I'))===JSON.stringify(expected.T2.slots.I.must_include));
 check('T2 O explicit result only',entries(T2,'O').length===1&&entries(T2,'O')[0].value.deliverable==='release-audit.md'&&entries(T2,'O')[0].value.type==='验收记录');
 check('T2 three file reads',JSON.stringify(action(T2,'读取').map(e=>e.value.object))===JSON.stringify(['deployment.yaml','healthcheck.json','test.log']));
 check('T2 two checks',JSON.stringify(action(T2,'执行').map(e=>e.value.object))===JSON.stringify(['配置一致性检查','健康检查']));
 check('T2 complete A set',entries(T2,'A').length===9&&action(T2,'核验')[0]?.value.object==='payment-service'&&action(T2,'生成').length===1&&action(T2,'汇报').length===1);
 check('T2 backup condition retained',entries(T2,'I').find(e=>e.value.entity==='backup-test.log')?.condition[0]?.members[0]?.text==='test.log 为空');
 check('T2 report condition and recipient',action(T2,'汇报')[0]?.value.recipient==='发布经理'&&action(T2,'汇报')[0]?.condition[0]?.members[0]?.text==='发现高危安全问题');
 check('T2 participants + role',entries(T2,'P').length===2&&entries(T2,'P')[0].value.participant==='李工'&&entries(T2,'P')[0].value.role==='质量工程师'&&entries(T2,'P')[1].condition.length===1);
 check('T2 duration <=45min',entries(T2,'R').length===1&&entries(T2,'R')[0].value.value===45&&entries(T2,'R')[0].value.operator==='<='&&entries(T2,'R')[0].value.unit==='minute');
 check('T2 basis exact',JSON.stringify(display(T2,'V'))===JSON.stringify(['CR-2026-118','v3.4.1']));
 check('T2 completion AND / stop only',entries(T2,'C').length===2&&entries(T2,'C')[0].value.operator==='AND'&&JSON.stringify(entries(T2,'C')[0].value.members.map(m=>m.text))===JSON.stringify(['配置一致性检查通过','健康检查通过','release-audit.md 已生成'])&&entries(T2,'C')[1].value.type==='STOP');
 check('T2 forbid / restrict set',JSON.stringify(entries(T2,'B').map(e=>[e.value.type,e.value.action,e.value.objects]))===JSON.stringify([['RESTRICT','读取',['deployment.yaml','healthcheck.json','test.log']],['FORBID','修改',['任何配置文件']],['FORBID','连接',['生产数据库']]]));
 check('T2 no broken predicates',T2.frames.every(f=>!['payment','发布','时'].includes(f.predicate.surface)));
 const texts=['读取 7 个 schema 文件。','如果缓存为空，则重新读取 cache.json。','当检查通过且 report.md 已生成时，任务完成。','发现异常后向发布经理汇报。','检查 order-service，不得重启该服务。','检查 api.yaml 并记录问题。'];
 for(const [i,t] of texts.entries())results['M'+(i+1)]=await parse7Plus1(t);
 const {M1,M2,M3,M4,M5,M6}=results;
 check('M1 count is not resource',M1.slots.I.status==='resolved'&&M1.slots.A.status==='resolved'&&M1.slots.R.status==='absent');
 check('M2 guard not completion',M2.slots.C.status==='absent'&&entries(M2,'A')[0]?.condition[0]?.relation==='IF_GUARD');
 check('M3 completion AND',M3.slots.C.status==='resolved'&&entries(M3,'C')[0]?.value.operator==='AND'&&entries(M3,'C')[0]?.value.members.length===2);
 check('M4 recipient compound / ordinary report',action(M4,'汇报')[0]?.value.recipient==='发布经理'&&M4.slots.C.status==='absent'&&M4.frames.every(f=>f.predicate.surface!=='发布'));
 check('M5 atomic service + unique reference',entity(M5,'I')[0]==='order-service'&&entries(M5,'B')[0]?.value.objects[0]==='order-service');
 check('M6 absent + conjunct actions', ['V','R','C','B'].every(s=>M6.slots[s].status==='absent')&&entries(M6,'A').length===2);
 const contrasts={IDENTIFIER:'检查 REPORT-003 的内容。',SHARED_NEGATION:'不得读取 config.ini 并修改 secret.toml。',AMBIGUITY:'输入包括 a.json 和 b.json。输入包括 c.yaml。读取上述文件。',UNICODE:'检查 🧪 order-service。',UNSUPPORTED:'???',RENAMED:'依据变更请求 AB-2030-901 和版本标签 v8.6.2，由维护工程师赵工在验收环境核验 ledger-api。输入包括 spec.yaml、probe.json 和测试日志 run.log。赵工只允许读取这些文件，不得修改配置。任务需要生成检查记录 check.md，并在 12 分钟内完成。'};
 for(const [id,t] of Object.entries(contrasts))results[id]=await parse7Plus1(t);
 check('Reference literal not verb/basis',results.IDENTIFIER.frames.every(f=>f.predicate.surface!=='REPORT')&&results.IDENTIFIER.slots.V.status==='absent');
 check('Negative shared modality never positive A/I',results.SHARED_NEGATION.slots.I.status==='absent'&&results.SHARED_NEGATION.slots.A.status==='absent'&&entries(results.SHARED_NEGATION,'B').length===2);
 check('Ambiguous file sets never guessed',results.AMBIGUITY.slots.A.status==='unresolved'&&results.AMBIGUITY.coreference.some(c=>c.status==='UNKNOWN_REFERENT'));
 check('Unicode evidence remains exact',results.UNICODE.provenance.valid);
 check('Renamed identifiers/person/duration generalize',entity(results.RENAMED,'I').includes('ledger-api')&&action(results.RENAMED,'读取').length===3&&entries(results.RENAMED,'R')[0]?.value.value===12&&entries(results.RENAMED,'P')[0]?.value.participant==='赵工');
 check('Literal grammar not names',lexical(sourceDocument('a-b x_y config.ini a.b.c C:/tmp/x.log v9.2.1 AB-109 4a9f1c8')).length>=7);
 for(const [id,r] of Object.entries(results)){check(id+' exact emitted provenance',r.provenance.valid);check(id+' warm model load count zero',r.performance.model_load_count===0);check(id+' normalization no infrastructure failure',r.normalization.diagnostics.length===0);}
 const summary={status:checks.every(c=>c.pass)?'PASS':'FAIL',checks,failures:checks.filter(c=>!c.pass),cases:Object.keys(results),warmup:warm};
 if(write){const put=(n,v)=>fs.writeFileSync(new URL(n,BASE),JSON.stringify(v,null,2)+'\n',{flag:'wx'});put('T1-SIMPLE-ABSENCE-RESULT.json',T1);put('T2-COMPLEX-RESULT.json',T2);put('METHOD-CONTRAST-RESULTS.json',{summary,results:Object.fromEntries(Object.entries(results).filter(([id])=>!['T1','T2'].includes(id)))});
  put('LEXICAL-PROTECTION-AUDIT.json',Object.fromEntries(Object.entries(results).map(([id,r])=>[id,{literals:r.signals.literals,clauses:r.signals.clauses}])));
  put('SEMANTIC-FRAME-AUDIT.json',Object.fromEntries(Object.entries(results).map(([id,r])=>[id,r.frames])));
  for(const [filename,key] of [['COORDINATION-AUDIT.json','coordination'],['DISCOURSE-AUDIT.json','discourse'],['BOUNDARY-PROJECTION-AUDIT.json','decisions'],['SLOT-STATE-AUDIT.json','slots'],['PERFORMANCE-AUDIT.json','performance']])put(filename,Object.fromEntries(Object.entries(results).map(([id,r])=>[id,r[key]])));
  put('VALIDATION.json',summary);put('NLP-MODEL-ROLE-AUDIT.json',{policy:T2.normalization.policy,linguistic_call:'linguistic.analyze -> persistent worker HanLP/spaCy',linguistic_models:T2.signals.models,semantic_calls:Object.values(results).flatMap(r=>r.normalization.models),warmup:warm,mdeberta_v3_base_main_path:false,llm_used:false,fallback:'Normalization labels remain unsupported; source facts and unknown references are unchanged.'});
 }
 return summary;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){try{const r=await evaluate({write:process.argv.includes('--write')});console.log(JSON.stringify({status:r.status,checks:r.checks.length,failures:r.failures},null,2));if(r.status!=='PASS')process.exitCode=1;}finally{closeNlp();}}
