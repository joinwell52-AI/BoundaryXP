export const SLOT_IDS=['I','O','A','P','R','V','C','B'];
const conditionText=f=>f.condition.map(c=>c.members.map(m=>m.text).join(' AND ')).join(' AND ');
export function project(semantic){
 const slots=Object.fromEntries(SLOT_IDS.map(s=>[s,{status:null,entries:[]}])),decisions=[];
 function emit(slot,f,display,value,argumentsUsed=[],modality=f.modality){
  const condition=f.condition,ev=[...argumentsUsed.flatMap(a=>a.evidence??[]),...f.evidence,...condition.flatMap(c=>[...c.evidence,...c.members.flatMap(m=>m.evidence)])];
  const state=argumentsUsed.some(a=>a.state==='UNRESOLVED')||f.state!=='RESOLVED'?'UNRESOLVED':'RESOLVED';
  const key=JSON.stringify([display,conditionText(f),modality]),previous=slots[slot].entries.find(e=>e.identity===key);
  if(previous){previous.evidence.push(...ev);previous.frame_refs.push(f.id);return;}
  slots[slot].entries.push({id:`entry:${slot}:${slots[slot].entries.length}`,identity:key,display,modality,state,value,condition,frame_refs:[f.id],evidence:ev,projection_rule:'PURPOSE_MODALITY_RELATION_'+slot});
 }
 for(const f of semantic.frames){
  const pred=f.predicate.surface,cond=conditionText(f),prefix=cond?`若 ${cond}：`:'',before=Object.values(slots).reduce((n,s)=>n+s.entries.length,0);
  if(f.kind==='INPUT_DECLARATION')for(const a of f.object)emit('I',f,a.surface,{entity:a.surface,type:a.entity_type},[a]);
  if(f.kind==='TASK_ACTION'&&f.modality!=='FORBID'){
   const targets=f.object.length?f.object:[null];
   for(const a of targets){const recipient=f.recipient.map(x=>x.surface).join('、');const display=recipient?`向${recipient}${pred}${a?.surface??''}`:pred+(a?.surface??'');emit('A',f,prefix+display,{action:pred,object:a?.surface??null,recipient,continuation:f.continuation??null},[...(a?[a]:[]),...f.recipient],f.modality==='RESTRICT'?'ALLOW':f.modality);}
   if(['TASK_ACTION','RESTRICTED_PERMISSION'].includes(f.purpose))for(const a of f.object.filter(a=>!['EVENT_NOMINAL','EVENT_COMPLEMENT'].includes(a.entity_type)))emit('I',f,prefix+(a.surface??'对象待确认'),{entity:a.surface,type:a.entity_type},[a],'DECLARE');
   for(const a of f.location)emit('I',f,a.surface,{entity:a.surface,type:'LOCATION'},[a],'DECLARE');
  }
  for(const a of f.result)emit('O',f,a.surface+(a.result_type?`（${a.result_type}）`:''),{deliverable:a.surface,type:a.result_type},[a]);
  for(const a of [...f.actor,...f.recipient]){
   const m=/^(.*(?:工程师|经理|主管|负责人))(.+(?:工|先生|女士))$/u.exec(a.surface),name=m?.[2]??a.surface,role=m?.[1]??null;
   // Actor identity is independent of an action guard; recipients retain their guard.
   const pf=a.role==='AGENT'?{...f,condition:[],state:a.state}:f;
   emit('P',pf,name+(role?`（${role}）`:'')+(a.role==='RECIPIENT'?' · 接收汇报':''),{participant:name,role,relation:a.role},[a],'DECLARE');
  }
  for(const a of f.limit)emit('R',f,`${a.surface}内`,{type:'DURATION',operator:a.operator,value:a.value,unit:a.unit},[a]);
  for(const a of f.basis)emit('V',f,a.surface,{basis:a.surface},[a]);
  if(f.kind==='COMPLETION')emit('C',f,'完成条件：'+cond,{type:'COMPLETION',operator:'AND',members:f.condition.flatMap(c=>c.members)},[]);
  if(['STOP','ESCALATION'].includes(f.kind))emit('C',f,prefix+pred+f.object.map(a=>a.surface).join('、'),{type:f.kind,action:pred,objects:f.object.map(a=>a.surface)},f.object);
  if(['FORBID','RESTRICT'].includes(f.modality))emit('B',f,prefix+(f.modality==='FORBID'?'禁止':'仅允许')+pred+f.object.map(a=>a.surface??'对象待确认').join('、'),{type:f.modality,action:pred,objects:f.object.map(a=>a.surface)},f.object);
  decisions.push({frame_id:f.id,purpose:f.purpose,modality:f.modality,emitted_count:Object.values(slots).reduce((n,s)=>n+s.entries.length,0)-before});
 }
 for(const [id,s] of Object.entries(slots)){
  s.coverage_complete=!semantic.diagnostics.some(d=>d.affected_slots?.includes(id));
  s.status=!s.coverage_complete?'parser_coverage_failure':s.entries.length?s.entries.some(e=>e.state!=='RESOLVED')?'unresolved':'resolved':'absent';
  // No synthetic unresolved entries or false absence when coverage is incomplete.
 }
 return {slots,decisions};
}
