import {id,uniq} from '../../v0.3-7p-composition-014/identity.mjs';
import {buildSemanticOwnership} from '../../v0.3-7p-composition-014/semantic-ownership.mjs';
import {graphApi,length} from './graph-api.mjs';
export function prepareOwnership(f){for(const a of f.analyses){const text=a.cl.span.quote;const review=/^\s*(?:[A-Z][A-Z0-9_-]*|[\p{Script=Han}]{2,8})\s*(?:确认|复核|审核).*后$/u.test(text)||a.cl.tokens.some((t,i)=>/^(确认|复核|审核|confirm|review)$/iu.test(t.text)&&a.cl.tokens.some(s=>s.head===i&&s.dep==='nsubj')&&a.cl.tokens.some(m=>m.head===i&&m.dep==='case'&&/^(后|之后)$/u.test(m.text)));const current=/^(?:不执行|不得|禁止|严禁)/u.test(text)&&/文档|报告/u.test(text);if(a.discourse.kind==='OUTPUT_CONTENT'&&(review||current)){a.discourse={...a.discourse,kind:'CURRENT_TASK',ownership_recovery_rule:'EXPLICIT_OUTER_REVIEW_OR_CONSTRAINT'};for(const n of f.semantic_nodes.filter(n=>n.metadata.clause_id===a.cl.id))n.metadata.discourse=a.discourse;}
 if((contentSyntax(text)||/(?:在|列入)(?:报告|文档)(?:中|里|内)?/u.test(text)&&/(?:列出|列入|写明|标记|记录)/u.test(text)||/(?:时|后).*(?:逐项列出|写明|标记|标为|保持待确认)/u.test(text)||/(?:条目|信息|项目|模型)\s*(?:必须|应)?(?:标为|标记为)/u.test(text)||/^(?!任务)(?:.+?)(?:应|需|必须|只|单独|分别)(?:单独)?(?:记录|列出|标记)(?:为|原因|$)/u.test(text)||/^只列出/u.test(text))&&!review&&!current){a.discourse={...a.discourse,kind:'OUTPUT_CONTENT',ownership_recovery_rule:'EXPLICIT_CONTENT_PREDICATE_OWNER'};a.r2_nonexecution=true;for(const n of f.semantic_nodes.filter(n=>n.metadata.clause_id===a.cl.id))n.metadata.discourse=a.discourse;}
 }return f;}
const contentSyntax=text=>/^(?:并|也)?(?:在)?(?:其中|报告|文档|指南|纪要|(?:the\s+)?(?:report|document|guide))\s*(?:中|里|内)?\s*(?:必须|须|应|要|只|must)?\s*(?:逐项|明确|原样|分别|单独)?\s*(?:包含|写入|写明|列出|说明|记录|contain|include)/iu.test(text);
// Discourse classification is separate from execution candidate generation.
// The requirement keeps its own source even when its words resemble actions.
export function closeContentAndStructure(f){
 const {retire,edge,outputs}=graphApi(f),records=f.semantic_decoding.discourse.output_content_requirements;
 f.semantic_decoding.output_content_ir={requirements:[],structural_nodes:[]};const log=f.semantic_decoding.output_content_ir;
 for(const a of f.analyses){const raw=a.cl.span.quote;
  const documentOnly=/^(?:本任务|任务|this task|the task)\s*(?:只|仅|only)\s*(?:交付|编写|deliver|write)\s*(?:文档|文件|documents?)$/iu.test(raw);
  if(documentOnly){const owners=outputs(a);if(owners.length!==1)continue;retire(a,'EXPLICIT_DOCUMENT_ONLY_DELIVERY_ENVELOPE');const state=f.tools.node(a.cl,'STATE',a.cl.span.start,a.cl.span.end,{sense:'DOCUMENT_ONLY_DELIVERY_ENVELOPE',owner:owners[0].node_id,discourse:a.discourse,quantifier:'ONLY',current_execution:false,modality:'REQUIRED'}),r=edge(a,'CONJUNCTION',state,owners[0]);a.state=state;log.structural_nodes.push({node_id:state.node_id,clause_id:a.cl.id,owner_output_ids:[owners[0].node_id],source_span_ids:uniq([a.sid,...owners[0].source_span_ids]),relation_ids:[r.relation_id],rule:'EXPLICIT_DOCUMENT_ONLY_DELIVERY_ENVELOPE'});continue;}
  if(a.inline_output_content){const q=a.inline_output_content,ids=uniq(f.relations.filter(r=>r.state==='SUPPORTED'&&r.clause_id===a.cl.id&&r.relation_type==='RESULT').map(r=>r.tail_node_id));if(ids.length===1){const output=f.semantic_nodes.find(n=>n.node_id===ids[0]),state=f.tools.node(a.cl,'STATE',q.start,q.end,{sense:'OUTPUT_CONTENT_REQUIREMENT',owner:output.node_id,discourse:{...a.discourse,kind:'OUTPUT_CONTENT'},content_text:[...f.source.raw_text].slice(q.start,q.end).join('')}),r=edge(a,'CONJUNCTION',state,output),req={requirement_id:id(state.node_id,'inline-content'),clause_id:a.cl.id,semantic_node_ids:[state.node_id],owner_output_ids:ids,ownership_status:'UNIQUE_OUTPUT',ownership_evidence_relation_ids:[r.relation_id],source_span_ids:uniq([a.sid,...state.source_span_ids,...output.source_span_ids]),content_text:state.surface,rule:'EXPLICIT_INLINE_OUTPUT_SECTION_DECLARATION'};records.push(req);log.requirements.push(req);}}
  const clarification=/^(?:\d+(?:\.\d+)?\s*(?:分钟|天|%|次)?\s*(?:是.*(?:窗口|限制|分类)|只用于分类)|不作为.*资源预算|不是(?:任务时限|查询次数|重试|资源约束)|该(?:文字|内容|语句).*不构成.*授权|这只是文档内容|不代表本任务实际执行)/u.test(raw);
  if(clarification){const owners=outputs(a);if(owners.length!==1)continue;retire(a,'EXPLICIT_SOURCE_ROLE_CLARIFICATION');const state=f.tools.node(a.cl,'STATE',a.cl.span.start,a.cl.span.end,{sense:'SOURCE_ROLE_CLARIFICATION',owner:owners[0].node_id,discourse:a.discourse,clarification_text:raw,current_execution:false}),r=edge(a,'CONJUNCTION',state,owners[0]);a.state=state;const record={node_id:state.node_id,requirement_id:id(state.node_id,'clarification-owner'),clause_id:a.cl.id,semantic_node_ids:[state.node_id],source_span_ids:uniq([a.sid,...owners[0].source_span_ids]),relation_ids:[r.relation_id],ownership_evidence_relation_ids:[r.relation_id],owner_output_ids:[owners[0].node_id],ownership_status:'UNIQUE_OUTPUT',rule:'EXPLICIT_SOURCE_ROLE_CLARIFICATION'};log.structural_nodes.push(record);records.push(record);continue;}
  const retained=records.find(q=>q.clause_id===a.cl.id&&q.ownership_status==='UNIQUE_OUTPUT'&&(['TYPED_CONTENT','TYPED_OUTPUT_SECTION'].includes(q.content_parsing_status)));
  if(retained){log.requirements.push(retained);continue;}
  if(/^#{1,6}\s+\S/u.test(raw)){
   retire(a,'MARKDOWN_HEADING_IS_STRUCTURAL');const n=f.tools.node(a.cl,'DISCOURSE',a.cl.span.start,a.cl.span.end,{sense:'SECTION_HEADING',discourse:a.discourse,owner:a.discourse.owner_structure_id});log.structural_nodes.push({node_id:n.node_id,clause_id:a.cl.id,source_span_ids:[a.sid],structural_path:a.discourse.structural_path});continue;
  }
  const explicit=/^(?:并|也)?(?:在)?(?:报告|文档|指南|纪要|report|document|guide)\s*(?:中|里|内)?\s*(?:必须|须|应|要|must)?\s*(?:逐项|明确|原样|分别|单独)?\s*(?:包含|写入|写明|列出|说明|记录|contain|include)/iu.test(raw)||/在报告中(?:单独)?列出/u.test(raw)||/(?:应|必须)(?:列入报告|标记为|标为)/u.test(raw)&&!/不得|禁止/u.test(raw)||/保持待确认/u.test(raw);
  const list=/^(?:(?:必须|须|否则)\s*)?(?:列出|写明|标记|单独列出|分别列出)/u.test(raw);
  const recorded=/^(?:必须|须|应)?(?:在报告中|在文档中|标记为|记为)/u.test(raw)&&/(?:待确认|未确认|无差异|已批准|记录)/iu.test(raw);
  if(!explicit&&!list&&!recorded&&a.discourse.kind!=='OUTPUT_CONTENT')continue;
  const owners=outputs(a);if(!owners.length)continue;
  const title=/(?:报告|文档|指南|report|document|guide)/iu.exec(raw);
  const specific=f.nlp_signals.literals.filter(l=>['FILE','PATH'].includes(l.type)&&l.span.start>=a.cl.span.start&&l.span.end<=a.cl.span.end);
  const named=owners.filter(n=>specific.some(l=>l.span.quote===n.surface));const domain=named.length?named:owners;
  retire(a,'OUTPUT_CONTENT_REQUIREMENT_SEPARATED_FROM_EXECUTION');a.discourse={...a.discourse,kind:'OUTPUT_CONTENT'};
  const state=f.tools.node(a.cl,'STATE',a.cl.span.start,a.cl.span.end,{sense:'OUTPUT_CONTENT_REQUIREMENT',owner:a.cl.id,discourse:a.discourse,polarity:'POSITIVE',content_text:raw});a.state=state;
  const relation_ids=domain.length===1?[edge(a,'CONJUNCTION',state,domain[0]).relation_id]:[];
  const requirement={requirement_id:id(f.source.sha256,a.cl.id,'content'),clause_id:a.cl.id,semantic_node_ids:[state.node_id],owner_output_ids:domain.length===1?[domain[0].node_id]:[],ownership_status:domain.length===1?'UNIQUE_OUTPUT':'AMBIGUOUS_OUTPUT',ownership_evidence_relation_ids:relation_ids,source_span_ids:uniq([a.sid,...domain.flatMap(n=>n.source_span_ids)]),content_text:raw,rule:specific.length?'EXPLICIT_ARTIFACT_CONTENT':'UNIQUE_ROOT_OUTPUT_CONTENT_DOMAIN'};
  records.push(requirement);log.requirements.push(requirement);
  if(domain.length!==1){const u=f.tools.unknown(a.cl,'UNRESOLVED_SCOPE','Output-content requirement has multiple explicit output owners',domain.map(n=>n.node_id));state.unresolved_ref=u;state.state='UNRESOLVED';}
 }
 log.requirements= [...new Map([...log.requirements,...records.filter(r=>r.ownership_status==='UNIQUE_OUTPUT')].map(r=>[r.requirement_id,r])).values()];
 f.tools.attachContext();buildSemanticOwnership(f,'ADMIN_ROOT_019_CONTENT');return f;
}
export function closeEmbeddedInputs(f){const {edge,expr}=graphApi(f);f.semantic_decoding.embedded_artifact_ir=[];
 for(const a of f.analyses)for(const e of a.events){if(!['read','review'].includes(e.metadata.sense)||!['REQUIRED','PERMITTED'].includes(e.metadata.modality))continue;
  for(const r of f.relations.filter(r=>r.state==='SUPPORTED'&&r.head_node_id===e.node_id&&r.relation_type==='PATIENT')){
   const object=f.semantic_nodes.find(n=>n.node_id===r.tail_node_id);
   for(const s of object.metadata.embedded_artifact_spans??[]){const artifact=f.tools.node(a.cl,'ENTITY',s.start,s.end,{sense:'ARTIFACT',literal_tag:'FILEPATH',artifact_identity:id('ARTIFACT',s.quote),owner:a.cl.id,discourse:a.discourse});const witness=edge(a,'SCOPE_MEMBER',f.tools.task,artifact);const q=expr(f.expressions.set_expr_nodes,{kind:'ITEM',entity_node_id:artifact.node_id,source_span_ids:uniq([a.sid,...artifact.source_span_ids]),relation_ids:[witness.relation_id]});f.relation_scope_plans.set(witness.relation_id,q);f.semantic_decoding.embedded_artifact_ir.push({event_node_id:e.node_id,object_node_id:object.node_id,artifact_node_id:artifact.node_id,source_span_ids:[a.sid,...artifact.source_span_ids],relation_ids:[witness.relation_id]});}
  }
 }return f;}

