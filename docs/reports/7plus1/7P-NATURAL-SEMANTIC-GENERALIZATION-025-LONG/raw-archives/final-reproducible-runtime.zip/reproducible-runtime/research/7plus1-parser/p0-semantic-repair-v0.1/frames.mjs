const auxiliary=/^(?:不|得|不得|必须|需要|应当|应|须|能|只能|只|可|可以|允许|继续|才|已|当|为|是|must|may|can|should|be|is|do|not)$/iu;
const resultOperator=/^(?:生成|输出|交付|产出|generate|produce|deliver|output)$/iu;
const stopOperator=/^(?:停止|中止|终止|stop|abort)$/iu;
const escalationOperator=/^(?:升级|escalate)$/iu;
const reference=/^(?:上述|这些|那些|该|它|this\b|these\b|it\b)/iu;
const hasVerb=(c,t)=>['VV','VA','VERB','AUX'].includes(t.pos)||Object.values(c.pos_alternatives??{}).some(tags=>/^v/u.test(tags[c.tokens.indexOf(t)]??''))||(c.srl??[]).some(group=>group.some(a=>a[1]==='PRED'&&a[2]<=c.tokens.indexOf(t)&&a[3]>c.tokens.indexOf(t)));
export function buildFrames(doc,signals){
 const frames=[],diagnostics=[],accountability=[],coordination=[],coreference=[],discourse=[];let actor=null,guard=null,completion=null;const inputSets=[];
 const ev=(c,span,rule)=>({source_span:span,structure_ref:c.id,linguistic_signal_refs:c.tokens.filter(t=>t.start<span.end&&t.end>span.start).map(t=>t.id),rule_id:rule});
 const arg=(c,span,role,extra={})=>({role,surface:span.quote,state:'RESOLVED',evidence:[ev(c,span,'SOURCE_ARGUMENT')],...extra});
 const make=(c,kind,pred=c.span)=>{const f={id:'frame:'+frames.length,kind,purpose:kind,modality:'DECLARE',state:'RESOLVED',predicate:{surface:pred.quote,normalized:null},predicate_span:pred,actor:[],object:[],result:[],recipient:[],location:[],basis:[],limit:[],condition:[],scope:[],evidence:[ev(c,c.span,'FRAME_'+kind)],clause_ref:c.id,syntactic_layer_id:c.id};frames.push(f);return f;};
 const trim=(start,end)=>{while(start<end&&/\s/u.test(doc.span(start,start+1).quote))start++;while(end>start&&/\s/u.test(doc.span(end-1,end).quote))end--;return doc.span(start,end);};
 const local=(c,a,b)=>doc.span(c.span.start+[...c.span.quote.slice(0,a)].length,c.span.start+[...c.span.quote.slice(0,b)].length);
 const inSpan=(l,s)=>l.span.start>=s.start&&l.span.end<=s.end;
 const find=(text,start)=>{const tail=doc.span(start,doc.source.codepoint_length).quote,index=tail.indexOf(text);if(index<0)throw Error('SPAN_NOT_FOUND');return start+[...tail.slice(0,index)].length;};
 function entities(c,span,role){
  const files=signals.literals.filter(l=>['FILE','PATH','URI','IDENTIFIER'].includes(l.type)&&inSpan(l,span));
  if(files.length){const values=files.map(l=>arg(c,l.span,role,{entity_type:l.type}));if(values.length>1)coordination.push({type:'ENTITY',operator:'AND',members:values,evidence:[ev(c,span,'EXPLICIT_LITERAL_ENUMERATION')]});return values;}
  const parts=span.quote.split(/、|和|与|\band\b/iu).map(s=>s.trim()).filter(Boolean);const repeatedHead=parts.length>1&&parts.every(p=>p.endsWith(parts[0].slice(-2)));
  if(repeatedHead){let cursor=span.start;const values=parts.map(p=>{const start=find(p,cursor);cursor=start+[...p].length;return arg(c,doc.span(start,cursor),role,{entity_type:'EVENT_NOMINAL'});});coordination.push({type:'EVENT',operator:'AND',members:values,evidence:[ev(c,span,'COORDINATED_SHARED_NOMINAL_HEAD')]});return values;}
  return span.quote?[arg(c,span,role,{entity_type:'NOUN_PHRASE'})]:[];
 }
 function states(c,span){
  const text=span.quote.replace(/^(?:只有当|当|如果|若|并且|且|when\s+|if\s+)/iu,'').replace(/(?:时|之后)$/u,'').trim();
  let cursor=span.start;const members=text.split(/、|并且|且|\band\b/iu).map(x=>x.trim()).filter(Boolean).map(part=>{const start=find(part,cursor);cursor=start+[...part].length;const s=doc.span(start,cursor),f=make(c,'STATE',s);f.state_structure={text:part,polarity:/(?:不|未|not\b)/iu.test(part)?'NEGATIVE':'POSITIVE',span:s};return {frame_ref:f.id,text:part,evidence:[ev(c,s,'STATE_IN_CONDITION')]};});if(members.length>1)coordination.push({type:'STATE',operator:'AND',members,evidence:[ev(c,span,'EXPLICIT_STATE_CONJUNCTION')]});return members;
 }
 const clauses=signals.clauses.flatMap(c=>{
  if(/^(?:如果|若|只有当|当|并且|if\b|when\b)/iu.test(c.span.quote))return [c];
  const cuts=c.tokens.filter((t,i)=>/^(?:并|并且|and)$/iu.test(t.text)&&c.tokens.slice(0,i).some(x=>hasVerb(c,x)&&!auxiliary.test(x.text))&&c.tokens.slice(i+1).some(x=>hasVerb(c,x)&&!auxiliary.test(x.text)));
  if(!cuts.length)return [c];coordination.push({type:'EVENT',operator:'AND',members:cuts.map((_,i)=>c.id+':conj:'+i).concat(c.id+':conj:'+cuts.length),evidence:cuts.map(t=>ev(c,t.span,'EXPLICIT_EVENT_CONJUNCTION'))});const bounds=[c.span.start,...cuts.map(t=>t.end),c.span.end];
  return bounds.slice(0,-1).map((start,i)=>{const end=cuts[i]?.start??c.span.end,indices=c.tokens.map((t,j)=>t.start>=start&&t.end<=end?j:-1).filter(j=>j>=0);return {...c,id:c.id+':conj:'+i,parent_clause:c.id,conj_index:i,span:trim(start,end),tokens:indices.map(j=>({...c.tokens[j],head:indices.indexOf(c.tokens[j].head)})),pos_alternatives:Object.fromEntries(Object.entries(c.pos_alternatives??{}).map(([key,tags])=>[key,indices.map(j=>tags[j])])),srl:[]};});
 });
 let previous=null;
 for(const c of clauses){
  const q=c.span.quote,startCount=frames.length,record={clause_ref:c.id,source_span:c.span,state:'ACCOUNTED',frame_refs:[]};accountability.push(record);
  if(guard&&guard.sentence!==c.sentence_id)guard=null;
  const basis=/^(?:依据|按照|基于|根据|according to\b|based on\b)/iu.exec(q);
  const duration=signals.literals.find(l=>l.type==='DURATION'&&inSpan(l,c.span));
  if(basis){const f=make(c,'BASIS',local(c,0,basis[0].length));f.basis=signals.literals.filter(l=>['REFERENCE','VERSION','COMMIT'].includes(l.type)&&inSpan(l,c.span)).map(l=>arg(c,l.span,'BASIS'));if(!f.basis.length){f.basis=[arg(c,c.span,'BASIS')];f.state='UNRESOLVED';}}
  else if(duration&&/(?:内|不超过|至多|within|at most)/iu.test(q)&&/(?:完成|结束|finish|complete)/iu.test(q)){
   const f=make(c,'RESOURCE_LIMIT',duration.span);f.limit=[arg(c,duration.span,'LIMIT',{operator:'<=',value:Number(duration.span.quote.match(/[\d.]+/u)[0]),unit:/分钟|minute/iu.test(duration.span.quote)?'minute':/小时|hour/iu.test(duration.span.quote)?'hour':'second'})];
  }
  else if(/^(?:只有当|当|when\b)/iu.test(q)){
   completion={sentence:c.sentence_id,parts:states(c,c.span),evidence:[ev(c,c.span,'CONDITION_ANTECEDENT')]};
  }
  else if(completion&&/^(?:任务|工作|流程|task|work)\s*(?:才|就|即|is\s+)?(?:完成|结束|complete|done)/iu.test(q)){
   const f=make(c,'COMPLETION');f.condition=[{relation:'COMPLETION',operator:'AND',members:completion.parts,evidence:completion.evidence}];f.evidence.push(...completion.evidence);discourse.push({type:'COMPLETION',from:completion.parts.map(p=>p.frame_ref),to:f.id});coordination.push({type:'CONDITION',operator:'AND',members:completion.parts});completion=null;
  }
  else if(completion&&completion.sentence===c.sentence_id){completion.parts.push(...states(c,c.span));completion.evidence.push(ev(c,c.span,'CONDITION_CONTINUATION'));}
  else if(/^(?:如果|若|if\b|unless\b)/iu.test(q)){
   guard={sentence:c.sentence_id,relation:'IF_GUARD',operator:'AND',members:states(c,c.span),evidence:[ev(c,c.span,'IF_ANTECEDENT')]};discourse.push({type:'IF_GUARD',antecedents:guard.members});
  }
  else if(/^(?:输入(?:包括|为|是)|inputs?\s*(?:include|are|:))/iu.test(q)){
   const m=/^(?:输入(?:包括|为|是)|inputs?\s*(?:include|are|:))/iu.exec(q),f=make(c,'INPUT_DECLARATION',local(c,0,m[0].length));f.object=entities(c,trim(c.span.start+[...m[0]].length,c.span.end),'TASK_INPUT');inputSets.push({frame_ref:f.id,members:f.object});
  }
  else{
   const protectedToken=t=>signals.literals.some(l=>t.start>=l.span.start&&t.end<=l.span.end);
   let heads=c.tokens.filter(t=>hasVerb(c,t)&&!auxiliary.test(t.text)&&!protectedToken(t)&&!['compound:nn','amod','nmod:assmod'].includes(t.dep));
   // Alternative POS/SRL may correct a compound-tag ambiguity only outside protected phrases.
   if(!heads.length)heads=c.tokens.filter(t=>hasVerb(c,t)&&!auxiliary.test(t.text)&&!protectedToken(t));
   // An explicit prepositional recipient with a nominal root is a verbal-noun construction.
   const root=c.tokens.find(t=>/^(?:root|ROOT)$/u.test(t.dep));
   if(!heads.length&&root&&!protectedToken(root)&&c.tokens.some(t=>/^(?:向|给|to)$/iu.test(t.text)&&['P','ADP'].includes(t.pos)))heads=[root];
   const sequence=c.tokens.find(t=>/^(?:最后|然后|随后|finally|then)$/iu.test(t.text));if(sequence)discourse.push({type:'SEQUENCE',evidence:[ev(c,sequence.span,'SEQUENCE_ADVERB')]});
   const inlineGuard=!sequence&&/^(.+?)后(?=向|给)/u.exec(q);if(inlineGuard){const span=local(c,0,inlineGuard[1].length);guard={sentence:c.sentence_id,relation:'WHEN_GUARD',operator:'AND',members:states(c,span),evidence:[ev(c,span,'TEMPORAL_GUARD')]};heads=heads.filter(t=>t.start>=span.end+1);}
   const head=heads[0];
   if(!head){record.state='COVERAGE_FAILURE';diagnostics.push({code:'NO_SUPPORTED_PREDICATE',source_span:c.span,affected_slots:['I','O','A','P','R','V','C','B']});}
   else{
    const prefix=doc.span(c.span.start,head.start).quote,f=make(c,'TASK_ACTION',head.span);f.syntax_signal=head.id;
    f.modality=/不得|禁止|不能|不允许|\b(?:do not|must not|forbid)\b/iu.test(prefix)?'FORBID':/只允许|只能|仅允许|\bonly\b/iu.test(prefix)?'RESTRICT':/允许|可以|(?:^|并)可|\bmay\b/iu.test(prefix)?'ALLOW':'REQUIRE';
    if(c.conj_index>0&&previous?.parent_clause===c.parent_clause&&!/不得|禁止|不能|允许|必须|需要|\b(?:must|may|can)\b/iu.test(prefix)){f.modality=previous.modality;f.modality_inheritance={from:previous.id,path:[c.parent_clause,c.id],evidence:previous.evidence};f.evidence.push(...previous.evidence);}
    f.parent_clause=c.parent_clause;previous=f;
    if(f.modality==='FORBID')f.purpose='PROHIBITION';if(f.modality==='RESTRICT')f.purpose='RESTRICTED_PERMISSION';
    const by=c.tokens.find(t=>t.text==='由'||/^by$/iu.test(t.text));
    if(by){const location=signals.literals.find(l=>l.type==='LOCATION_PHRASE'&&inSpan(l,c.span)),end=location?location.span.start-1:head.start;const s=trim(by.end,end);if(s.quote){actor=arg(c,s,'AGENT');f.actor=[actor];}}
    if(!f.actor.length){const subject=c.tokens.find(t=>t.head===c.tokens.indexOf(head)&&t.dep==='nsubj'&&['NR','PROPN'].includes(t.pos));if(subject){actor=arg(c,subject.span,'AGENT');f.actor=[actor];}else if(actor)f.actor=[{...actor,inherited:true,attachment_path:['explicit_task_actor',c.id]}];}
    for(const l of signals.literals.filter(l=>l.type==='LOCATION_PHRASE'&&inSpan(l,c.span)))f.location.push(arg(c,l.span,'LOCATION'));
    const prep=c.tokens.find(t=>/^(?:向|给|to)$/iu.test(t.text)&&t.start<head.start);if(prep){const recipient=trim(prep.end,head.start);if(recipient.quote)f.recipient=[arg(c,recipient,'RECIPIENT')];}
    let end=c.span.end;const continuation=c.tokens.find(t=>t.start>head.end&&/^(?:继续|然后|最后|continue|then)$/iu.test(t.text));if(continuation){end=continuation.start;f.continuation={text:doc.span(end,c.span.end).quote,evidence:[ev(c,doc.span(end,c.span.end),'CONTINUATION_NOT_NEW_EVENT')]};}
    const objectSpan=trim(head.end,end);f.object=entities(c,objectSpan,'PATIENT');
    if(c.tokens.some(t=>t.start>head.end&&hasVerb(c,t)&&t.dep==='ccomp')&&!continuation){f.purpose='ACTION_COMPLEMENT';f.object.forEach(a=>a.entity_type='EVENT_COMPLEMENT');}
    if(f.object.length===1&&reference.test(f.object[0].surface)){
     const original=f.object[0],fileRef=/文件|files?/iu.test(original.surface),sets=inputSets.filter(s=>fileRef&&s.members.every(m=>['FILE','PATH'].includes(m.entity_type)));
     if(sets.length===1){f.object=sets[0].members.map(a=>({...a,role:'PATIENT',evidence:[...a.evidence,...original.evidence],reference_surface:original.surface,attachment_path:[sets[0].frame_ref,f.id]}));coreference.push({status:'RESOLVED',reference:original,antecedent_set:sets[0].frame_ref,members:f.object});}
     else{const localEntities=frames.filter(x=>x.id!==f.id&&x.purpose==='TASK_ACTION').flatMap(x=>x.object).filter(a=>a.entity_type==='IDENTIFIER');const unique=[...new Map(localEntities.map(a=>[a.surface,a])).values()];if(!fileRef&&/^该(?:服务|模块|系统)$/u.test(original.surface)&&unique.length===1){f.object=[{...unique[0],role:'PATIENT',evidence:[...unique[0].evidence,...original.evidence],reference_surface:original.surface}];coreference.push({status:'RESOLVED',reference:original,members:f.object,rule:'UNIQUE_TYPED_LOCAL_ENTITY'});}else{original.state='UNRESOLVED';original.referent_type='UNKNOWN_REFERENT';f.state='UNRESOLVED';coreference.push({status:'UNKNOWN_REFERENT',reference:original,candidate_sets:sets.map(s=>s.frame_ref)});}}
    }
    if(guard)f.condition=[{...guard}];
    if(stopOperator.test(head.text)){f.kind='STOP';f.purpose='STOP';}
    else if(escalationOperator.test(head.text)){f.kind='ESCALATION';f.purpose='ESCALATION';}
    else if(resultOperator.test(head.text)&&f.object.length){if(f.object.some(a=>/^(?:时|后|前|内)$/u.test(a.surface))){f.state='UNRESOLVED';diagnostics.push({code:'TEMPORAL_MARKER_NOT_RESULT',source_span:objectSpan,affected_slots:['O','A']});}else{f.purpose='DELIVERABLE';f.result=f.object.map(a=>({...a,role:'RESULT',result_type:doc.span(head.end,a.evidence[0].source_span.start).quote.trim()}));}}
    if(!f.object.length&&!f.recipient.length&&f.purpose==='TASK_ACTION'){f.state='UNRESOLVED';f.object=[arg(c,head.span,'PATIENT',{surface:null,state:'UNRESOLVED',referent_type:'UNKNOWN_REFERENT'})];}
   }
  }
  record.frame_refs=frames.slice(startCount).map(f=>f.id);
 }
 if(completion){diagnostics.push({code:'UNATTACHED_CONDITION',affected_slots:['A','C'],evidence:completion.evidence});}
 const nodes=[],relations=[];for(const f of frames){nodes.push({id:f.id,type:f.kind==='STATE'?'STATE':'EVENT',...f});for(const key of ['actor','object','result','recipient','location','basis','limit'])for(const a of f[key]){const id=f.id+':'+key+':'+nodes.length;nodes.push({id,type:a.referent_type??a.entity_type??'ENTITY',...a});relations.push({type:a.role,from:f.id,to:id,evidence:a.evidence});}for(const c of f.condition)for(const member of c.members)relations.push({type:c.relation,operator:c.operator,from:member.frame_ref,to:f.id,evidence:[...member.evidence,...c.evidence]});}
 return {frames,gsg:{nodes,relations},diagnostics,accountability,coordination,coreference,discourse};
}
