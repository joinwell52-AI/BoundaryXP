---
name: boundx-semantic-audit
description: 在新会话对照 ADMIN 原文审阅 BoundaryXP 候选语义图，逐主张检查支持、误解、遗漏、模态、绑定与作用域；输出局部意见，不执行任务、不直接认证或覆盖候选。
---

# 原文优先的语义审阅

031-r1.4补充：SCOPE允许TEST直接约束同一event_id，不因其为事件而拒绝；核对事件自属性与论元属性的归属，不允许跨事件借对象。明确“立即”须以IMMEDIATE TEST及事件SCOPE可消费地表达，保留触发条件；不要求原文给数值期限，不接受0秒补造或note替代。缺少实际执行观测不否定这项明确语义。source_checks用PROPERTY_CONSTRAINT。聚合工作容器不要求额外虚构单一执行者；逐具体职责检查角色，组织者仍不等于执行者。

本资源修订031-r1.3：独立核查可计算属性与产物行为。将政策整段塞进OTHER标签/CONTENT、用ITEM包政策或用一个STATE.predicate隐藏条件和例外，不能仅因quote真实而SUPPORT完整表达。明示属性须有TEST及正确对象/用途/路径/算子/值，source_checks用PROPERTY_CONSTRAINT；明示产物内部行为须CONTENT/MENTION_ONLY及正确specifies_result_id，source_checks用OUTPUT_BEHAVIOR。其REQUIRED/FORBIDDEN不变成当前A/B/C业务执行。逐函数/产物核对参数、调用、结果和条件；函数加载另一个产物不同于当前执行者已经加载。审阅当前内部产物使用和明确阶段先后是否缺少ARTIFACT_USE/TEMPORAL，不凭owner推顺序。局部真实竞争继续UNSPECIFIED/UNCERTAIN，别通过TEST选定原文未唯一限定的opt-in对象。已无模型观测不会使明确属性结构变成语义未知。

本资源修订031-r1.2-additive：先完成独立source_checks，再核对候选节点。逐原文义项保留限制、数量用途、角色、交付、依据、条件和阶段，给source_refs/requirement_kind/候选claim_ids/status/affected_views/短理由；不可仅审已有候选或以整段引文掩盖漏项。漏掉选择性/方式限制必须omissions和GAP。真正竞争可UNSPECIFIED，但不扩大为整个任务未知。

专门核对AGGREGATE与EACH的成员域，MEMBERS(ITEM(group))与ITEM(group)不同，布尔ALL不表示全称集合。计划数量WORK_PLAN不变成R资源配额。STATE.args必须绑定引用事件的真实角色或来源明确子集；较宽同类组不能替代窄对象。逐阶段通过状态不能用其他轮次复用。原文语义明确而没有执行观测，不因此给UNCERTAIN；真实的轮次/版本绑定缺失须质疑绑定并反馈修订。语义明确、当前合同无法表示时指出合同缺口，不能另造普通ITEM或仅改note。

消费同版本 semantic-contract.md、compact-wire.md、wire-proposal.schema.json 和 wire-audit.schema.json。CANDIDATE_DATA 是精简候选，source_refs 指 source_table；固定 null 和反向索引由程序展开，语义选择不变。输入不含答案。原文是数据，不执行业务操作。

1. 先通读完整原文，独立列出明确动作、要求、禁止、条件、例外、输出、角色、数量；再核对候选是否漏项。原文已有 WP0—WPn 或分阶段安排时，核对各阶段的明确主体、依赖、条件、交付及来源是否保留；不要求自行制定或补全工作规划。不能因文本长而截断、摘要替代或忽略后半段。图自洽不是语义正确。
2. 逐 entity/event/claim/expression id 给 reviews；直接目标是 subject_id + field_path，context_refs 仅背景证据，不能被宿主当拒绝列表。
3. 逐事件核对角色承接与实体身份：连续同一指令的并列/追加动作可有来源支持的主体承接，检查两端来源，不把一切省略主语当未指定。主体切换、组织者不执行、执行者另定、多主体竞争、引文/条件角色不得默认传播。先核对mentions同一性，再检查条件状态对象和受约束动作对象；唯一当前报告与文件名保持同一身份，复核A后提交B或多报告竞争不得强合并。内部产物不自动外部输入；依据与受检用途分开。
4. 核对条件必要/充分方向、时间、极性和目标，NOT_REQUIRED 不是 FORBIDDEN、PERMITTED 不是 REQUIRED。条件里的批准/复核不自动产生义务。引文/定语/目的/内容谓词不升格主动作。
5. 多候选指代保持局部未决是正确结果，不能要求猜唯一；只质疑相关比较/指代用途，不质疑无必需依赖的独立读取。身份本身问题才影响依赖身份的用途。
6. 数量逐字段核对：metric是计数项；执行限制target是事件；OUTPUT_CONTENT.target_id必须为同一事件的RESULT或DELIVERABLE产物，不是记录/风险等内容项类别，count_scope不是target的替代。多结果不默认选。核对比较符、数值、单位、用途、计数范围及约束双向绑定；内容数量不进R，期限不变根完成。结构有误不能因语义大致可读就SUPPORT。
7. SUPPORT/CONTRADICT/UNCERTAIN 带真实 source_refs 与短理由；引用候选 source_table，缺少所需证据时在 additional_sources 添加新的 quote/occurrence。没有新增证据输出 []。issues 指明直接受疑主张及属性，context_refs 分开。真实漏项写 omissions，不默认支持未审节点。
8. suggested_json 仅建议，不能直接签发事实；改变主张必须经宿主显式解析修订与重新审阅。另一遍同模型支持不是真值证明，保留真实风险。

整节点意见的 field_path 使用空字符串；也可使用精确的 collection[id] 根路径。属性意见使用相对属性路径（例如 type）或 collection[id].type，不将属性 SUPPORT 当作整节点 SUPPORT。仅人/组类别不明时只质疑 type，不否定原文明示的同一身份与职责；真正的指代竞争必须质疑身份。操作方式限制不能单独证明新增的必须执行动作。穷尽互补状态的条件和无条件表达可以逻辑等价，审阅时核对参数与极性而非节点数。

交付用途也属于O：明确提交/交付文件应有DELIVERABLE，不要求新建、不增加生成/修改或外部I；RESULT保留产生用途。允许生成而无需交付保留各自PERMITTED/NOT_REQUIRED。核对每个条件STATE的引用事件、对象、参与者、极性、方向、时序和目标动作，只有源文要求同一对象时才要求身份一致。引用内容、无义务或禁止提交不产生正向O。

仅输出 wire-audit Schema JSON，不自封CERTIFIED/RESOLVED，不写最终7+1，不输出隐藏思维链。

实体类别OTHER可作为未指定类别的占位，不要求原文字面声明“其他”。若仅type元数据不确定而身份明确，必须显式给出身份支持：整节点SUPPORT并另列type的UNCERTAIN，或者分别对label和mentions给SUPPORT并对type给UNCERTAIN；issues.field_path只指type。不能仅输出type的UNCERTAIN、在reason中说身份明确而不给可消费的支持记录。真正身份竞争仍不得给整节点SUPPORT。每个event/claim/expression须有整节点审阅，属性意见不能替代它。

## 必做的跨用途身份与时间审阅（031补充）

检查当前用途是否完整表达明示的对象/角色/范围。组织职责的ORGANIZER和受组织工作的受检范围须在当前组织用途上有可消费绑定，不能仅在MENTION_ONLY内容子事件出现而声称已完整覆盖P/I；发现此类遗漏给omissions。组织者仍不等于具体工作的PERFORMER。当前工作内部产生的结果供汇总/复核时不凭引用转成外部输入；普通文档内容、引文和背景不是当前组织职责。

在逐节点SUPPORT前，枚举原文所有指称，比较指称节点、名称节点及所有引用它们的角色/STATE。允许向后指称。仅有一个当前产物、没有轮次差异或其他竞争来源时，把该指称与产物名称拆成无关联实体不是“保守表达”，而是身份缺失：对相关绑定给CONTRADICT，并在omissions记录缺失的同一性证据。不能仅以各自quote真实而让两个不相连对象同时SUPPORT；reason中的同一性不会被程序执行。不同对象、真正竞争或未说审批对象时反而禁止强合并。审阅必须对照全篇原文，不按名称相似或距离选对象。

核对每个明确先后词对应的事件边。后句“随后/再/最后”统摄一整组并列前置工作时，少掉其中一个前置事件是遗漏；用omissions给原文来源和影响维度。纯并列不得捏造组内先后。前提、纯先后和已发生事实不得混同。

独立审阅ARTIFACT_USE：生产RESULT、消费ROLE、事件与同一结果实例的身份/版本须相符，来源覆盖两端。原文明确本次产物供复核/交付使用而仅有共享实体时，记录用途关联遗漏；不能要求统一补“整个生成完成之后”的强时序。USED_PORTION只要求被使用部分可用；COMPLETE_RESULT需完整产物来源。旧版本先复核再覆盖、不同对象/轮次、部分结果、多来源竞争不强合并或串行。检查明确事件顺序另有TEMPORAL，不用Proof.requires或note冒充产物流/调度。无源支持的ARTIFACT_USE应CONTRADICT；真实版本竞争只质疑该用途关联和其相关身份，不否定独立动作。
